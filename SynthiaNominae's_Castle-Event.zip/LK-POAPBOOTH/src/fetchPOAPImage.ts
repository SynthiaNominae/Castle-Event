@EventConstructor()
class FetchImage {
    image:string
  constructor(image:string) {
    this.image = image
  }
}