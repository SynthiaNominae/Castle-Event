

const canvas = new UICanvas()

export var poapText = new UIText(canvas)
poapText.value = "POAP was sent to your address!\nhttps/\/\:app.poap.xyz"
poapText.vAlign = "center"
poapText.hAlign = "center"
poapText.hTextAlign = "center"
poapText.fontSize = 50
poapText.positionX = 0
poapText.height = 30
poapText.color = Color4.Yellow()
poapText.visible = false